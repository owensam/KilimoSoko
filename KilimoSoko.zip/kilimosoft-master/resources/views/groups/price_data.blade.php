@extends('groups.layout.layout')

@section('content')


 <div class="w3-row">

<div class="w3-col l12 w3-center">






          {!! $chart->render() !!}




</div>

</div>


@stop
